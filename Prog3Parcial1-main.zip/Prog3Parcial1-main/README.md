# Prueba-APIRest-P3
El siguiente repositorio contiene el parcial No. 1 de la materia Programacion 3, de la TSP 2023.

En este proyecto de muestra se implementa una API REST en Spring Boot. Se utiliza SQL como base de datos y manejo de las entidades: 
- Autor
- Libro
- Localidad
- Domicilio
- Persona

Documentacion de API realizada en POSTMAN.
