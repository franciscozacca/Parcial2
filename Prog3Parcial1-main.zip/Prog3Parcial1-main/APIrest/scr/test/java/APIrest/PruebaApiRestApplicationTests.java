package com.example.pruebaapirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaApiRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
