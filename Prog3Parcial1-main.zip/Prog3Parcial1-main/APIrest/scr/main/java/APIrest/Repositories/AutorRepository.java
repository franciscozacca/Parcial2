package com.example.pruebaapirest.Repositories;

import com.example.pruebaapirest.Entities.Autor;
import org.springframework.stereotype.Repository;

@Repository
public interface AutorRepository extends BaseRepository<Autor, Long>{
}
