package com.example.pruebaapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaApiRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(PruebaApiRestApplication.class, args);
    }

}
