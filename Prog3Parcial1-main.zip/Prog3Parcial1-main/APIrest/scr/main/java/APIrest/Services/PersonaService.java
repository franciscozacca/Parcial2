package com.example.pruebaapirest.Services;

import com.example.pruebaapirest.Entities.Persona;

public interface PersonaService extends BaseService<Persona, Long>{
}
