package com.prog3.ApiRest.services;

import com.prog3.ApiRest.entities.Domicilio;

public interface DomicilioService extends  BaseService<Domicilio, Long> {
}
