package com.example.pruebaapirest.Services;

import com.example.pruebaapirest.Entities.Localidad;

public interface LocalidadService extends BaseService<Localidad, Long>{
}
