package com.example.pruebaapirest.Services;

import com.example.pruebaapirest.Entities.Autor;

public interface AutorService extends BaseService<Autor, Long>{
}
