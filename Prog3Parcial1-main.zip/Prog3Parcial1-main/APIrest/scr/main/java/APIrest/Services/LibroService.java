package com.prog3.ApiRest.services;

import com.prog3.ApiRest.entities.Libro;

public interface LibroService extends BaseService<Libro,Long> {
}
